import 'package:flutter/material.dart';

class AppColors {
  static const Color blue = Color(0xFF0D315C);
  static const Color orange = Color(0xFFFF6A00);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
}
